package com.aot.pms.abs;

public interface IExitListener {
    void exit();
}
